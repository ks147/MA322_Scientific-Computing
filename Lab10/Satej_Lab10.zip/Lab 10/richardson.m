function y=richardson(x,t,time0,time1,f,alpha)
    m = length(x)-1 ;
    n = length(t)-1 ;
    h = x(2)-x(1) ;
    k = t(2)-t(1) ; 
    y = zeros(m+1,n+1) ;
    lam = ((alpha^2)*k)/h^2 ;
    for i=1:m+1
       y(i,1)= f(x(i)) ; 
    end
    t= 0:k:1 ;
    for i=1:n+1
        y(1,i)=time0(t(i));
        y(m+1,i)=time1(t(i));
    end
    for i=2:m
            y(i,2)= (1-2*lam)*y(i,1) + lam*(y(i+1,1) + y(i-1,1)) ;
    end
    for j=3:n+1
        for i=2:m
            y(i,j)= y(i,j-2) + 2*lam*(y(i+1,j-1) + y(i-1,j-1)-2*y(i,j-1)) ;
        end
    end
    
end