function y=btcs(x,t,time0,time1,f,alpha)
    m = length(x)-1 ;
    n = length(t)-1 ;
    h = x(2)-x(1) ;
    k = t(2)-t(1) ; 
    y = zeros(m+1,n+1) ;
    lam = ((alpha^2)*k)/h^2 ;
    for i=1:m+1
       y(i,1)= f(x(i)) ; 
    end
    t= 0:k:1 ;
    for i=1:n+1
        y(1,i)=time0(t(i));
        y(m+1,i)=time1(t(i));
    end
    A = zeros(m+1,m+1) ;
    A(1,1)=1 ;
    A(m+1,m+1)=1 ;
    for i=2:m
        A(i,i) = (1+2*lam) ;
        A(i,i-1)=-lam ;
        A(i,i+1)=-lam ;
    end
    A = inv(A) ;
    B = zeros(m+1,1) ;
    for j=1:n
       B(1)=y(1,j+1);
       B(m+1)=y(m+1,j+1);
       for i=2:m
           B(i)=y(i,j);
       end
       y(:,j+1)=A*B ;
    end
    
    
end