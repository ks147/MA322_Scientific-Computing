function graph_plot(pref,name,xr,method,exact,ms,ns,k,no)
    N = zeros(1,k) ;
    error = zeros(1,k) ;
    for i=1:k
        m= ms * 2^(i-1) ;
        n =ns ;
        N(i) = m ;
        xs = linspace(0,xr,m);
        ys= linspace(0,1,n);
        zs = method(xs,ys) ;
        ex = method(xs,ys) ;
        w= exact(xs,1) ;
        
        error(i) = max(max(abs(w-zs(:,n)))) ;
        if i==k
            figure(1+4*no) ;
            hold on ;
            plot(xs,w);
            plot(xs,zs(:,n));
            legend('exact','approx');
            title(sprintf('%s m=%d n=%d  ', name, m, n));
            saveas(gcf, sprintf('%s%d-%d-final_time.jpg', pref, m, n));
            hold off ;

            [X,Y] =meshgrid(xs,ys) ;
            figure(2+4*no) ;
            surf(X,Y,zs');
            legend('approx');
            title(sprintf('%s m=%d n=%d  ', name, m, n));
            saveas(gcf, sprintf('%s%d-%d-approx.jpg', pref, m, n));
            figure(3+4*no) ;
            surf(X,Y,ex');
            legend('exact');
            title(sprintf('%s m=%d n=%d  ', name, m, n));
            saveas(gcf, sprintf('%s%d-%d-exact.jpg', pref, m, n));
        end
        
    end
    figure(4+4*no);
    plot(log10(N), log10(error));
    legend({'Max-Error'});
    title(sprintf('%s m=%d n=%d  ', name, m, n));
    saveas(gcf, sprintf('%serror.jpg', pref));
end

