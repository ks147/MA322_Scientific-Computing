clear all ;
clc ;
time0=@(x) 0 ;
time1 =@(x) 0 ;
f =@(x) sin(pi*x/4)*(1+2*cos(pi*x/4)) ;
xr =4 ;
alpha = 2/pi ;
exact = @(x,t) exp(-t)*sin(pi*x/2) + exp(-t/4)*sin(pi*x/4) ;
graph_plot('1a-ftcs-','FTCS' ,xr, @(xs,ys)ftcs(xs,ys,time0,time1,f,alpha),exact,4,10000,5,0);
graph_plot('1a-btcs-','BTCS' ,xr, @(xs,ys)btcs(xs,ys,time0,time1,f,alpha),exact,4,10000,5,1);
graph_plot('1a-crank_nickolson-','Crank Nickolson' ,xr, @(xs,ys)crank(xs,ys,time0,time1,f,alpha),exact,4,10000,5,2);
graph_plot('1a-richardson-','Richardson' ,xr, @(xs,ys)richardson(xs,ys,time0,time1,f,alpha),exact,3,1000,3,3);
graph_plot('1a-dufort_frankel-','Dufort Frankel' ,xr, @(xs,ys)dufort(xs,ys,time0,time1,f,alpha),exact,4,10000,5,4);


