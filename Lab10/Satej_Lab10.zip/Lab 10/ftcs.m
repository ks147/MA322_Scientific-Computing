function y=ftcs(xs,ys,time0,time1,f,alpha)
    m = length(xs)-1 ;
    n = length(ys)-1 ;
    h = xs(2)-xs(1) ;
    k = ys(2)-ys(1) ; 
    y = zeros(m+1,n+1) ;
    lam = ((alpha^2)*k)/h^2 ;
    for i=1:m+1
       y(i,1)= f(xs(i)) ; 
    end
    t= 0:k:1 ;
    for i=1:n+1
        y(1,i)=time0(ys(i));
        y(m+1,i)=time1(ys(i));
    end
    for j=2:n+1
        for i=2:m
            y(i,j)= (1-2*lam)*y(i,j-1) + lam*(y(i+1,j-1) + y(i-1,j-1)) ;
        end
    end
    
end