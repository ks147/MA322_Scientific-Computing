clear all ;
clc ;

time0=@(x) 0 ;
time1 =@(x) exp(-pi^2*x/4) ;
f =@(x) sin(pi*x/2)+sin(2*pi*x)/2 ;
xr =1 ;
alpha = 1 ;
exact = @(x,t) exp(-pi^2*t/4)*sin(pi*x/2) + exp(-4*pi^2*t)*sin(2*pi*x)/2 ;

graph_plot('FTCS' ,xr, @(xs,ys)ftcs(xs,ys,time0,time1,f,alpha),exact,2,1000,4,0);
graph_plot('BTCS' ,xr, @(xs,ys)btcs(xs,ys,time0,time1,f,alpha),exact,2,1000,4,1);
graph_plot('Crank Nickolson' ,xr, @(xs,ys)crank(xs,ys,time0,time1,f,alpha),exact,2,1000,4,2);
graph_plot('Richardson' ,xr, @(xs,ys)richardson(xs,ys,time0,time1,f,alpha),exact,2,100,2,3);
graph_plot('Dufort Frankel' ,xr, @(xs,ys)dufort(xs,ys,time0,time1,f,alpha),exact,2,1000,4,4);
