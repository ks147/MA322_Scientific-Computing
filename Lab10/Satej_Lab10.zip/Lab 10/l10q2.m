clear all ;
clc ;

time0=@(x) 0 ;
time1 =@(x) 0 ;
f =@(x) sin(pi*x) ;
xr =1 ;
alpha = 1 ;
exact = @(x,t) exp(-pi^2*t)*sin(pi*x);

graph_plot('FTCS' ,xr, @(xs,ys)ftcs(xs,ys,time0,time1,f,alpha),exact,4,10000,5,0);
graph_plot('BTCS' ,xr, @(xs,ys)btcs(xs,ys,time0,time1,f,alpha),exact,4,10000,5,1);
graph_plot('Crank Nickolson' ,xr, @(xs,ys)crank(xs,ys,time0,time1,f,alpha),exact,4,10000,5,2);
graph_plot('Richardson' ,xr, @(xs,ys)richardson(xs,ys,time0,time1,f,alpha),exact,5,100,2,3);
graph_plot('Dufort Frankel' ,xr, @(xs,ys)dufort(xs,ys,time0,time1,f,alpha),exact,4,10000,5,4);
